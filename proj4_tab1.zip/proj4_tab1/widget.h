#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    double **s_path;
    double **ssd_path;
    double **r_path;
    double **p_path;
    double **s_path_d;
    double **r_path_d;
    QVector<double> gr;
    QVector<double> mat;
    QString **ij_path;
    void get_data();
    void table_setup();
    void buttons_setup();
    void line_setup();
    void matrix_setup();
    int min(QString a , QString b);
    int min(int a , int b);
    int r_c;
    int c_c;
    QString replace_ij(QString str,QString i , QString j , QString ik , QString kj);
public slots:
    void get_path();
    void get_path_table();
    void fill_table();
    void draw_graph();
    void expectation();

private:
    Ui::Widget *ui;
};
#endif // WIDGET_H
