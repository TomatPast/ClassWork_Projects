#include "widget.h"
#include "ui_widget.h"
#include <iostream>
#include <string>
#include <string.h>
#include <string.h>
#include <qDebug>
#include <ctime>
#include <QLabel>
#include <QLayout>



Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setGeometry(0 , 0 , 1440 , 700);
    srand(time(0));

    //ui->tableWidget->setColumnWidth(1 , 80);
    //ui->tableWidget->setRowHeight(1 , 50);
    this->setGeometry(0 , 0 , 1440 , 780);
    r_c = 6;
    c_c = 6;
    table_setup();
    line_setup();
    buttons_setup();
    matrix_setup();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::table_setup()
{
    this->setGeometry(0,0,1440,r_c*40 + 140);
    ui->tableWidget->setGeometry(32,25 , c_c*40 + 25, r_c*40 + 23);
    ui->tableWidget_2->setGeometry(int(this->width()/2) + 30 ,25 , c_c*40 + 25 , r_c*40 + 23);

    ui->tableWidget->setColumnCount(c_c);
    ui->tableWidget->setRowCount(r_c);
    ui->tableWidget_2->setColumnCount(c_c);// задаем размеры таблиц
    ui->tableWidget_2->setRowCount(r_c);

    ui->tableWidget_2->setDisabled(0);

    for (int i = 0 ; i < ui->tableWidget->rowCount() ; i++)
    {
        ui->tableWidget->setRowHeight(i , 40);
        ui->tableWidget_2->setRowHeight(i , 40);
    }
    for(int i = 0 ; i < ui->tableWidget->columnCount() ; i++)
    {
        ui->tableWidget->setColumnWidth(i , 40);
        ui->tableWidget_2->setColumnWidth(i , 40);
    }
    //ui->tableWidget->setGeometry(32,25 , int(this->width()/2) - 62 , this->height() - 117);
    //ui->tableWidget_2->setGeometry(int(this->width()/2) + 30 ,25 , int(this->width()/2) - 62 , this->height() - 117);

}


void Widget::buttons_setup()
{
    ui->pushButton->setGeometry(32 , this->height() - 50 , 200 , 40);
    ui->pushButton_2->setGeometry(242 , this->height() - 50 , 200 , 40);
    ui->pushButton_3->setGeometry(452 , this->height() - 50 , 200 , 40);
    ui->pushButton_4->setGeometry(662 , this->height() - 50 , 200 , 40);
    ui->pushButton_5->setGeometry(872 ,this->height() - 50 , 200 , 40);

    ui->pushButton->setText("Заполнить таблицу");
    ui->pushButton_2->setText("Получить таблицу путей");
    ui->pushButton_3->setText("Получить путь");
    ui->pushButton_4->setText("Нарисовать граф");
    ui->pushButton_5->setText("Мат. Ожидание");

    connect(ui->pushButton , SIGNAL(clicked()) , SLOT(fill_table()));
    connect(ui->pushButton_2 , SIGNAL(clicked()) , SLOT(get_path_table()));
    connect(ui->pushButton_3 , SIGNAL(clicked()) , SLOT(get_path()));
    connect(ui->pushButton_5 , SIGNAL(clicked()) , SLOT(expectation()));

    ui->pushButton_3->setDisabled(1);
    ui->pushButton_4->setDisabled(1);


}

void Widget::line_setup()
{
     ui->line->setGeometry(int(this->width()/2) , 0 , 3 , this->height() - 60);
     ui->line_2->setGeometry(0 , this->height() - 60 ,this->width() , 3);
}

void Widget::matrix_setup()
{

    s_path = new double * [r_c];
    ssd_path = new double * [r_c];
    r_path = new double * [r_c];
    s_path_d = new double * [r_c];
    r_path_d = new double * [r_c];
    p_path = new double * [r_c];
    ij_path = new QString * [r_c];
        for(int i = 0 ; i < r_c;i++)
        {
            s_path[i] = new double[c_c];
            ssd_path[i] = new double[c_c];
            r_path[i] = new double[c_c];
            s_path_d[i] = new double[c_c];
            r_path_d[i] = new double[c_c];
            p_path[i] = new double[c_c];
            ij_path[i] = new QString[c_c];
        }
}

int Widget::min(QString a, QString b)
{

    return 1;
}

int Widget::min(int a, int b)
{
    if (a > b) return b;
    else return a;

}

QString Widget::replace_ij(QString str, QString i, QString j, QString ik, QString kj)
{

}

void Widget::get_path()
{
 //ui->tableWidget_2.se
}

void Widget::get_path_table()
{
    for (int i = 0 ; i < r_c ; i++)
    {
        for(int j = 0; j < c_c; j++)
        {
           s_path[i][j] = ui->tableWidget->item(i , j)->text().toDouble();
           //qDebug() << s_path[i][j];
        }
    }
    double green = 0;
    for (int k = 0 ; k < r_c; k++)
    {
        for(int i = 0; i < r_c; i++)
        {
            for ( int j = 0 ; j < c_c ; j++)
            {
               if (k != i && k!= j)
               {
                    r_path[i][j] = min(int(s_path[i][j]) , int(s_path[i][k] + s_path[k][j]));

                    //qDebug() << "r_path[i][j]  = " << r_path[i][j] << " | r_path[i][k] + r_path[k][j] = " << r_path[i][k] + r_path[k][j] <<" | min = " << min(int(r_path[i][j]) , int(r_path[i][k] + r_path[k][j]));
                    QTableWidgetItem *item = new QTableWidgetItem(QString::number(r_path[i][j]));
                    ui->tableWidget_2->setItem(i , j, item);
                    if (s_path[i][j] > r_path[i][j])
                    {
                        //green += 1;
                        qDebug() << "i: " << i+1 << "|j: " << j+1 << "|k:" << k+1 << "\n";
                        ui->tableWidget_2->item(i , j)->setBackground(QBrush(QColor(255,255,0)));
                    }
                    s_path[i][j] = r_path[i][j];
               }
            }
        }
    }
    for (int i = 0 ; i < r_c; i++)
    {
        for ( int j = 0 ; j < c_c ; j++)
        {
            if (r_path[i][j] < ssd_path[i][j])
            {
                green += 1;
                ui->tableWidget_2->item(i , j)->setBackground(QBrush(QColor(0,255,0)));
            }
        }
    }
    int size = r_c*c_c;
    gr.append(double(green/(size)));
    //qDebug() << "green = " << green << size << double(green/(size));
    qDebug() << "Отношение улучшенных путей к общему числу путей " << green/(size);
}

void Widget::fill_table()
{
    ui->tableWidget->setCurrentCell( 1 , 1);
    for(int i = 0 ; i < r_c ; i++)
    {
        for(int j = 0 ; j < c_c ; j++)
        {
            QString buff_str= "";
            int buff = rand()%100;
            if (i == j)
            {
                s_path[i][j] = 0;
                ssd_path[i][j] = 0;
                buff_str += QString::number(s_path[i][j]);
                QTableWidgetItem *item = new QTableWidgetItem(buff_str);
                ui->tableWidget->setItem(i , j, item);
            }else
            {
            s_path[i][j] = buff;
            ssd_path[i][j] = buff;
            buff_str += QString::number(s_path[i][j]);
            QTableWidgetItem *item = new QTableWidgetItem(buff_str);
            ui->tableWidget->setItem(i , j, item);
            }

        }
    }
}

void Widget::draw_graph()
{

}

void Widget::expectation()
{

    for(int m = 0 ; m < 1000 ; m++)
    {
        for(int i = 0 ; i < r_c ; i++)
        {
            for(int j = 0 ; j < c_c ; j++)
            {
                int buff = rand()%100;
                if (i == j)
                {
                    s_path_d[i][j] = 0;
                }else
                {
                    s_path_d[i][j] = buff;
                }

            }
        }
        double green = 0;
        for (int k = 0 ; k < r_c; k++)
        {
            for(int i = 0; i < r_c; i++)
            {
                for( int j = 0 ; j < c_c ; j++)
                {
                    if (k != i && k!= j)
                    {
                        r_path_d[i][j] = min(int(s_path_d[i][j]) , int(s_path_d[i][k] + s_path_d[k][j]));
                    }
                }
            }
        }
        for (int i = 0 ; i < r_c; i++)
        {
            for ( int j = 0 ; j < c_c ; j++)
            {
                if (r_path_d[i][j] < s_path_d[i][j])
                {
                    green += 1;
                }
            }
        }
        int size = r_c*c_c;
        mat.append(green/size);
    }
    double sum = 0;
    int length = mat.size();
    for (int i = 0 ; i < length ; i++)
    {
        sum += mat[i]/length;
    }
    QWidget * widget = new QWidget();
    QLayout * layout = new QVBoxLayout();
    QLabel *label = new QLabel();
    QString str = "Математчиеское ожидание выборочное относительного количества сокращенных путей равно : ";
    str += QString::number(sum);
    qDebug() << sum;
    label->setText(str);
    layout->addWidget(label);
    widget->setLayout(layout);
    widget->show();
}



